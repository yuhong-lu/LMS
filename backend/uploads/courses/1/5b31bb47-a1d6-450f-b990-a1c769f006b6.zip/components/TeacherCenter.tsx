
import React from 'react';
import { Teacher } from '../types';

const MOCK_TEACHERS: Teacher[] = [
  { id: '1', name: '张逸 博士', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Zhang', subject: '软件架构', courses: 5, rating: 4.9 },
  { id: '2', name: '顾安妮', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Annie', subject: '视觉传达', courses: 3, rating: 4.8 },
  { id: '3', name: '王博伦', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Wang', subject: '产品增长', courses: 8, rating: 5.0 },
  { id: '4', name: '李建军 教授', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Li', subject: '后端技术', courses: 12, rating: 4.7 },
];

const TeacherCenter: React.FC = () => {
  return (
    <div className="p-6 md:p-10 animate-in fade-in slide-in-from-right-2 duration-700">
      <div className="mb-10">
        <h1 className="text-lg font-bold text-slate-800 tracking-tight">教师资源中心</h1>
        <p className="text-slate-400 text-[11px] mt-1 font-medium">管理您的精英教育团队，追踪授课质量与反馈。</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {MOCK_TEACHERS.map(teacher => (
          <div key={teacher.id} className="bg-white rounded-[2.5rem] p-6 soft-shadow border border-slate-50 flex flex-col items-center group hover:border-indigo-100 transition-all">
            <div className="w-20 h-20 rounded-[2rem] bg-indigo-50 p-1 mb-4 relative">
                <img src={teacher.avatar} className="w-full h-full object-cover rounded-[1.8rem]" alt={teacher.name} />
                <div className="absolute -bottom-1 -right-1 w-7 h-7 bg-white rounded-full flex items-center justify-center soft-shadow border border-slate-50">
                    <i className="fa-solid fa-check-circle text-indigo-500 text-sm"></i>
                </div>
            </div>
            <h3 className="text-sm font-bold text-slate-800 group-hover:text-indigo-600 transition-colors">{teacher.name}</h3>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">{teacher.subject}</p>
            
            <div className="w-full grid grid-cols-2 gap-2 mt-6 pt-6 border-t border-slate-50">
                <div className="text-center">
                    <p className="text-[13px] font-bold text-slate-800">{teacher.courses}</p>
                    <p className="text-[9px] text-slate-400 font-bold tracking-tighter">在播课程</p>
                </div>
                <div className="text-center">
                    <p className="text-[13px] font-bold text-indigo-500">{teacher.rating}</p>
                    <p className="text-[9px] text-slate-400 font-bold tracking-tighter">综合评分</p>
                </div>
            </div>

            <button className="mt-6 w-full py-2.5 rounded-xl bg-slate-50 text-[11px] font-bold text-slate-500 hover:bg-indigo-50 hover:text-indigo-600 transition-all">
                查看教师详情
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TeacherCenter;
