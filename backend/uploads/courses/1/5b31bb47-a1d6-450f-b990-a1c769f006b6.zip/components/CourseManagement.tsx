
import React from 'react';
import { Course } from '../types';

const MOCK_DATA: Course[] = [
  // Fixed: 'instructor' property renamed to 'teacherName' and added missing 'description' property to satisfy Course interface
  { id: '1', title: 'React 架构模式实战', description: '深度实战 React 架构设计', teacherName: '张逸 博士', thumbnail: 'https://picsum.photos/seed/tech/600/400', enrolled: 1240, category: '架构', status: 'published' },
  { id: '2', title: 'AI 辅助设计流', description: '掌握 AI 驱动的设计流程', teacherName: '顾安妮', thumbnail: 'https://picsum.photos/seed/art/600/400', enrolled: 850, category: '设计', status: 'published' },
  { id: '3', title: '全栈产品增长指南', description: '全栈视角下的产品增长策略', teacherName: '王博伦', thumbnail: 'https://picsum.photos/seed/product/600/400', enrolled: 2100, category: '产品', status: 'draft' },
  { id: '4', title: '分布式系统原理', description: '分布式架构核心原理与实践', teacherName: '李建军 教授', thumbnail: 'https://picsum.photos/seed/system/600/400', enrolled: 430, category: '后端', status: 'published' },
  { id: '5', title: '创意插画表现力', description: '探索插画设计的创意表达', teacherName: '陈墨', thumbnail: 'https://picsum.photos/seed/paint/600/400', enrolled: 1120, category: '艺术', status: 'archived' },
];

const CourseManagement: React.FC = () => {
  return (
    <div className="p-6 md:p-10 animate-in fade-in slide-in-from-right-2 duration-700">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-xl premium-title text-slate-800">课程管理库</h1>
          <p className="text-slate-400 text-[11px] mt-1.5 font-medium tracking-wide">全局查看和编辑学院内的所有课程资源。</p>
        </div>
        <div className="flex gap-2">
            <button className="px-5 py-2.5 bg-white border border-slate-100 soft-shadow rounded-xl text-[11px] font-bold text-slate-600 hover:bg-slate-50 transition-all">
                导出报表
            </button>
            <button className="px-6 py-2.5 gradient-bg text-white rounded-xl text-[11px] font-bold hover:shadow-xl hover:shadow-indigo-500/20 transition-all flex items-center gap-2">
                <i className="fa-solid fa-plus-circle"></i>
                新建课程
            </button>
        </div>
      </div>

      <div className="bg-white rounded-[2.5rem] soft-shadow border border-slate-50 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50 border-b border-slate-100">
                <th className="px-8 py-5 text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em]">课程名称</th>
                <th className="px-8 py-5 text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em]">讲师</th>
                <th className="px-8 py-5 text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em]">学员数</th>
                <th className="px-8 py-5 text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em]">状态</th>
                <th className="px-8 py-5 text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em] text-right">管理</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {MOCK_DATA.map(course => (
                <tr key={course.id} className="hover:bg-slate-50/30 transition-colors group">
                  <td className="px-8 py-5">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-8 rounded-lg overflow-hidden shadow-sm">
                        <img src={course.thumbnail} className="w-full h-full object-cover" alt="" />
                      </div>
                      <div>
                        <p className="text-xs font-bold text-slate-800 group-hover:text-indigo-600 transition-colors">{course.title}</p>
                        <p className="text-[10px] text-slate-300 font-bold uppercase tracking-tight">{course.category}</p>
                      </div>
                    </div>
                  </td>
                  {/* Fixed: teacherName used instead of instructor */}
                  <td className="px-8 py-5 text-[11px] font-medium text-slate-500">{course.teacherName}</td>
                  <td className="px-8 py-5">
                    <span className="text-[10px] font-bold text-slate-400 bg-slate-50 px-2.5 py-1 rounded-full border border-slate-100/50">
                        {course.enrolled?.toLocaleString()}
                    </span>
                  </td>
                  <td className="px-8 py-5">
                    <span className={`text-[9px] font-bold px-2.5 py-1 rounded-full uppercase tracking-tighter ${
                      course.status === 'published' ? 'bg-emerald-50 text-emerald-600' :
                      course.status === 'draft' ? 'bg-amber-50 text-amber-600' : 'bg-slate-100 text-slate-300'
                    }`}>
                      {course.status === 'published' ? '已发布' : course.status === 'draft' ? '草稿' : '已存档'}
                    </span>
                  </td>
                  <td className="px-8 py-5 text-right">
                    <button className="w-9 h-9 rounded-xl hover:bg-white hover:soft-shadow text-slate-200 hover:text-indigo-500 transition-all border border-transparent hover:border-indigo-50">
                      <i className="fa-solid fa-gear text-xs"></i>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default CourseManagement;
