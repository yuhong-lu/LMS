
import React from 'react';
import { Discussion } from '../types';

const MOCK_THREADS: Discussion[] = [
  // Fixed: timestamp converted to string to match Discussion interface
  { id: '1', user: '陈小明', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Chen', content: '请问在 React 19 中，useActionState 应该如何结合传统的 redux-thunk 使用？', course: 'React 架构实战', replies: 12, timestamp: (Date.now() - 3600000).toString() },
  { id: '2', user: '林子璇', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Lin', content: '这周的 AI 设计课程作业提交截止日期是周五吗？还是周日？', course: 'AI 辅助设计', replies: 3, timestamp: (Date.now() - 7200000).toString() },
  { id: '3', user: '助教-老王', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Wang2', content: '同学们好，关于分布式系统第三章的课后思考题，我已经整理了答案。', course: '分布式系统原理', replies: 45, timestamp: (Date.now() - 86400000).toString() },
];

const DiscussionArea: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto p-6 md:p-10 animate-in fade-in slide-in-from-right-2 duration-700">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-lg font-bold text-slate-800 tracking-tight">学术讨论区</h1>
          <p className="text-slate-400 text-[11px] mt-1 font-medium">师生互动中心，共享知识与见解。</p>
        </div>
        <button className="px-4 py-2 gradient-bg text-white rounded-xl text-[11px] font-bold shadow-lg shadow-indigo-500/10">
          发起新话题
        </button>
      </div>

      <div className="space-y-4">
        {MOCK_THREADS.map(thread => (
          <div key={thread.id} className="bg-white p-6 rounded-[2rem] border border-slate-50 soft-shadow hover:border-indigo-100 transition-all group">
            <div className="flex gap-4">
              <img src={thread.avatar} className="w-10 h-10 rounded-full bg-slate-50" alt="" />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-xs font-bold text-slate-800 group-hover:text-indigo-600 transition-colors">{thread.user}</span>
                  {/* Fixed: parsing string timestamp back to Number for Date constructor */}
                  <span className="text-[10px] text-slate-300 font-medium italic">• {new Date(Number(thread.timestamp)).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed mb-4">{thread.content}</p>
                <div className="flex items-center justify-between">
                    <span className="text-[9px] font-bold text-indigo-400 bg-indigo-50 px-2 py-0.5 rounded-full uppercase tracking-tighter">
                        来自课程：{thread.course}
                    </span>
                    <div className="flex items-center gap-4 text-slate-300">
                        <span className="flex items-center gap-1.5 text-[10px] font-bold">
                            <i className="fa-regular fa-comment-dots"></i> {thread.replies} 回复
                        </span>
                        <button className="text-[10px] font-bold text-slate-400 hover:text-indigo-500 transition-colors">回复他</button>
                    </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default DiscussionArea;
