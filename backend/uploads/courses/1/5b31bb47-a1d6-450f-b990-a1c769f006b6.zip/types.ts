
export type UserRole = 'ROLE_ADMIN' | 'ROLE_TEACHER' | 'ROLE_STUDENT';

export interface User {
  id: number;
  username: string;
  email: string;
  studentNumber?: string;
  className?: string;
  role: UserRole;
  createdAt: string;
}

export interface AuthResponse {
  token: string;
  username: string;
  roles: string[];
}

export interface DashboardSummary {
  totalStudents: number;
  totalCourses: number;
  assignmentSubmissions: number;
  quizSubmissions: number;
}

export interface Course {
  id: string;
  title: string;
  description: string;
  syllabus?: string;
  teacherId?: number;
  teacherName?: string;
  thumbnail?: string; // 适配前端展示
  enrolled?: number;
  category?: string;
  status?: 'published' | 'draft' | 'archived';
  createdAt?: string;
}

export interface Teacher {
  id: string;
  name: string;
  avatar: string;
  subject: string;
  courses: number;
  rating: number;
}

export interface Discussion {
  id: string;
  title?: string;
  content: string;
  user?: string;
  avatar?: string;
  course?: string;
  courseId?: string;
  replies?: number;
  timestamp: string;
}

export interface ApiResponse<T> {
  data: T;
  message?: string;
  success?: boolean;
}

export type AppView = 'dashboard' | 'courses' | 'teachers' | 'discussions' | 'profile' | 'ai-lab';

export interface HistoryItem {
  id: string;
  originalImage: string;
  editedImage: string;
  prompt: string;
  timestamp: number;
}
