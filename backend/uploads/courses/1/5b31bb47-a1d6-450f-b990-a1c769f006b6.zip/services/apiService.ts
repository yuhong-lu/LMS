
import { Course, User, DashboardSummary, AuthResponse, ApiResponse, Discussion } from '../types';

// 注意：在本地开发环境下，配合 vite.config.ts 的 proxy 配置
// 这里的 BASE_URL 设为 '/api' 即可自动转发到 localhost:8080
const BASE_URL = '/api'; 

const getHeaders = () => {
  const token = localStorage.getItem('lms_token');
  return {
    'Content-Type': 'application/json',
    ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
  };
};

const handleResponse = async <T>(response: Response) => {
  if (response.status === 401 || response.status === 403) {
    const isLoginPage = window.location.pathname.includes('login');
    if (!isLoginPage) {
      localStorage.removeItem('lms_token');
      window.location.reload();
    }
  }
  
  const data = await response.json();
  if (!response.ok) {
    throw new Error(data.message || '网络请求错误');
  }
  return data as T;
};

export const apiService = {
  async login(credentials: any): Promise<AuthResponse> {
    const res = await fetch(`${BASE_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(credentials),
    });
    return handleResponse<AuthResponse>(res);
  },

  async getMe(): Promise<User> {
    const res = await fetch(`${BASE_URL}/users/me`, { headers: getHeaders() });
    return handleResponse<User>(res);
  },

  async getSummary(): Promise<DashboardSummary> {
    const res = await fetch(`${BASE_URL}/dashboard/summary`, { headers: getHeaders() });
    return handleResponse<DashboardSummary>(res);
  },

  async getCourses(): Promise<Course[]> {
    const res = await fetch(`${BASE_URL}/courses`, { headers: getHeaders() });
    return handleResponse<Course[]>(res);
  },

  async getTopics(courseId: string): Promise<Discussion[]> {
    const res = await fetch(`${BASE_URL}/discussions/courses/${courseId}/topics`, { headers: getHeaders() });
    return handleResponse<Discussion[]>(res);
  }
};
